# ⚡ FPS Boost Mod — Minecraft 1.21.1 Fabric

Mod FPS Boost untuk Minecraft versi **1.21.1** dengan Fabric Loader **0.19.2**.
Mod ini mengurangi lag, mengoptimasi memori, dan meningkatkan performa game secara keseluruhan.

---

## 📥 Cara Build (Compile)

### Syarat
- **Java 21** (wajib)
- **Gradle 8.8** (sudah termasuk via wrapper)
- Koneksi internet (untuk download dependensi pertama kali)

### Langkah Build
```bash
cd minecraft-mod
./gradlew build
```
File `.jar` hasil build akan ada di:
```
minecraft-mod/build/libs/fpsboost-1.0.0.jar
```

---

## 📂 Cara Install di Minecraft

1. Pastikan sudah install **Fabric Loader 0.19.2** untuk Minecraft 1.21.1
2. Pastikan sudah install **Fabric API** (versi 0.104.0+1.21.1)
3. Copy file `fpsboost-1.0.0.jar` ke folder:
   - Windows: `%AppData%\.minecraft\mods\`
   - Linux/Mac: `~/.minecraft/mods/`
4. Jalankan Minecraft dengan profil Fabric

---

## 🎮 Cara Pakai

### Buka GUI
Tekan tombol **`K`** saat di dalam game → muncul GUI FPS Boost

### Fitur-Fitur di GUI

| Fitur | Keterangan |
|-------|-----------|
| **Memory Reduce** | Aktifkan optimasi memori otomatis |
| **Aggressive GC** | Paksa Garbage Collector berjalan berkala (setiap 60 detik default) |
| **Kurangi Partikel** | Buang 50% partikel secara acak → FPS naik |
| **Matikan Partikel** | Matikan SEMUA partikel (maksimum FPS) |
| **Entity Culling** | Jangan render entiti yang terlalu jauh (default: 64 blok) |
| **Reduce Entity Tick** | Kurangi update tick entiti |
| **Optim. Chunk Load** | Optimasi loading chunk |
| **Fast Chunk Update** | Percepat update chunk |
| **Matikan Fog** | Hapus efek fog/kabut → FPS naik |
| **Matikan Awan** | Hapus rendering awan |
| **Matikan Sky Render** | Hapus rendering langit |
| **FPS Counter** | Tampilkan counter FPS |

### Tombol Bawah GUI
- **⚡ Bersihkan Memori Sekarang** → Langsung paksa GC dan bebaskan memori
- **Tutup** → Tutup GUI (atau tekan `Esc`)

---

## 🔧 Konfigurasi

Pengaturan disimpan otomatis di:
```
.minecraft/config/fpsboost.json
```
File ini bisa diedit manual kalau mau.

---

## 📁 Struktur Proyek

```
minecraft-mod/
├── build.gradle               ← Build config
├── gradle.properties          ← Versi Minecraft, Fabric, Mod
├── settings.gradle
├── gradle/wrapper/            ← Gradle wrapper
└── src/main/
    ├── java/com/fpsboost/
    │   ├── FpsBoostMod.java        ← Entry point utama
    │   ├── config/
    │   │   ├── FpsBoostConfig.java ← Model konfigurasi
    │   │   └── ConfigManager.java  ← Load/save JSON config
    │   ├── gui/
    │   │   └── FpsBoostScreen.java ← GUI setelan (buka dengan K)
    │   ├── keybind/
    │   │   └── KeyBindings.java    ← Daftarkan tombol K
    │   ├── mixin/
    │   │   ├── ParticleManagerMixin.java   ← Kurangi/matikan partikel
    │   │   ├── EntityRendererMixin.java    ← Entity culling
    │   │   ├── GameRendererMixin.java      ← Auto GC berkala
    │   │   ├── WorldRendererMixin.java     ← Matikan awan & langit
    │   │   └── BackgroundRendererMixin.java← Matikan fog
    │   └── util/
    │       └── MemoryUtils.java    ← Force GC & info RAM
    └── resources/
        ├── fabric.mod.json         ← Metadata mod
        ├── fpsboost.mixins.json    ← Daftar mixin
        └── assets/fpsboost/lang/
            └── en_us.json          ← Teks tombol keybind
```
