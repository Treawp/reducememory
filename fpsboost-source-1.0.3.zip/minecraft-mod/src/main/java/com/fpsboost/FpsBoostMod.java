package com.fpsboost;

import com.fpsboost.config.ConfigManager;
import com.fpsboost.keybind.KeyBindings;
import com.fpsboost.gui.FpsBoostScreen;
import com.fpsboost.util.MemoryUtils;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FpsBoostMod implements ClientModInitializer {

    public static final String MOD_ID = "fpsboost";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static int gcTickCounter = 0;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[FPS Boost] Mod dimuat! Versi 1.0.3 untuk Minecraft 1.21.11 Fabric");

        ConfigManager.load();
        KeyBindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Buka GUI
            while (KeyBindings.OPEN_GUI.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new FpsBoostScreen());
                }
            }

            // Auto GC berkala
            var cfg = ConfigManager.get();
            if (cfg.memoryReduce && cfg.aggressiveGC) {
                gcTickCounter++;
                int interval = cfg.gcIntervalSeconds * 20;
                if (gcTickCounter >= interval) {
                    gcTickCounter = 0;
                    MemoryUtils.forceGarbageCollect();
                }
            }
        });

        LOGGER.info("[FPS Boost] Tekan K untuk membuka GUI pengaturan.");
    }
}
