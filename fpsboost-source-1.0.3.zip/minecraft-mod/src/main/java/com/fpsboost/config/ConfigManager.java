package com.fpsboost.config;

import com.fpsboost.FpsBoostMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("fpsboost.json");

    public static FpsBoostConfig config = new FpsBoostConfig();

    public static void load() {
        File file = CONFIG_PATH.toFile();
        if (file.exists()) {
            try (Reader reader = new FileReader(file)) {
                config = GSON.fromJson(reader, FpsBoostConfig.class);
                if (config == null) config = new FpsBoostConfig();
                FpsBoostMod.LOGGER.info("[FPS Boost] Konfigurasi berhasil dimuat.");
            } catch (IOException e) {
                FpsBoostMod.LOGGER.error("[FPS Boost] Gagal memuat konfigurasi: " + e.getMessage());
                config = new FpsBoostConfig();
            }
        } else {
            config = new FpsBoostConfig();
            save();
        }
    }

    public static void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(config, writer);
            FpsBoostMod.LOGGER.info("[FPS Boost] Konfigurasi disimpan.");
        } catch (IOException e) {
            FpsBoostMod.LOGGER.error("[FPS Boost] Gagal menyimpan konfigurasi: " + e.getMessage());
        }
    }

    public static FpsBoostConfig get() {
        return config;
    }
}
