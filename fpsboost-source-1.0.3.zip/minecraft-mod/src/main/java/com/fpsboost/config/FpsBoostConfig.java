package com.fpsboost.config;

public class FpsBoostConfig {

    // === MEMORY ===
    public boolean memoryReduce = true;
    public boolean aggressiveGC = false;
    public int gcIntervalSeconds = 60;

    // === PARTICLE ===
    public boolean reduceParticles = true;
    public boolean disableAllParticles = false;

    // === ENTITY ===
    public boolean entityCulling = true;
    public int entityRenderDistance = 64;
    public boolean reduceEntityTick = false;
    public boolean disableNameTags = false;

    // === RENDERING ===
    public boolean disableFog = false;
    public boolean disableClouds = true;
    public boolean disableSkyRendering = false;
    public boolean smoothLighting = false;
    public boolean reducedBiomeFade = true;

    // === CHUNK ===
    public boolean optimizeChunkLoading = true;
    public boolean fastChunkUpdates = true;

    // === MISC ===
    public boolean showFpsCounter = true;
    public boolean limitFps = false;
    public int fpsLimit = 60;
}
