package com.fpsboost.gui;

import com.fpsboost.config.ConfigManager;
import com.fpsboost.config.FpsBoostConfig;
import com.fpsboost.util.MemoryUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class FpsBoostScreen extends Screen {

    private static final int BG_COLOR    = 0xCC0A0F18;
    private static final int PANEL_COLOR = 0xCC111C2A;
    private static final int ACCENT      = 0xFF00BBFF;
    private static final int CAT_COLOR   = 0xFFFFAA00;
    private static final int DIM_COLOR   = 0xFF888888;

    // Posisi section label disimpan untuk render()
    private int perfLabelY;
    private int chunkLabelY;
    private int visualLabelY;
    private int panelX, panelW;

    public FpsBoostScreen() {
        super(Text.literal("FPS Boost"));
    }

    @Override
    protected void init() {
        FpsBoostConfig cfg = ConfigManager.get();

        // ==== HITUNG LAYOUT DINAMIS ====
        // Panel: maks 400px, minimal memenuhi layar - 4px margin
        panelW = Math.min(400, width - 4);
        panelX = (width - panelW) / 2;

        int headerH = 48;   // tinggi header (judul)
        int footerH = 50;   // tinggi footer (RAM + tombol aksi)
        int contentH = height - headerH - footerH;

        // Dua kolom
        int pad = 8;
        int colGap = 6;
        int colW = (panelW - pad * 2 - colGap) / 2;
        int col1X = panelX + pad;
        int col2X = col1X + colW + colGap;

        // Kolom kiri: 2 section + 9 tombol
        // Kolom kanan: 1 section + 6 tombol
        // Maksimum baris = 9 (kolom kiri paling banyak)
        int numRows   = 9;
        int sectionH  = 14;  // tinggi label section
        int numSecL   = 2;   // jumlah section di kolom kiri
        int btnGap    = 3;   // gap antar tombol

        // Hitung tinggi button agar pas dalam contentH
        // contentH = numSecL*sectionH + numRows*btnH + (numRows-1)*btnGap
        int btnH = (contentH - numSecL * sectionH - (numRows - 1) * btnGap) / numRows;
        btnH = Math.max(14, Math.min(24, btnH));
        int rowH = btnH + btnGap;

        // ==== KOLOM KIRI — PERFORMA & CHUNK ====
        perfLabelY = headerH;
        int y = perfLabelY + sectionH;

        addToggle(col1X, y, colW, btnH, "Memory Reduce",   cfg.memoryReduce,
                () -> { cfg.memoryReduce     = !cfg.memoryReduce;     ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Aggressive GC",   cfg.aggressiveGC,
                () -> { cfg.aggressiveGC     = !cfg.aggressiveGC;     ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Kurangi Partikel",cfg.reduceParticles,
                () -> { cfg.reduceParticles  = !cfg.reduceParticles;  ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Matikan Partikel",cfg.disableAllParticles,
                () -> { cfg.disableAllParticles = !cfg.disableAllParticles; ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Entity Culling",  cfg.entityCulling,
                () -> { cfg.entityCulling    = !cfg.entityCulling;    ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Reduce Ent. Tick",cfg.reduceEntityTick,
                () -> { cfg.reduceEntityTick = !cfg.reduceEntityTick; ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Semb. NameTag",   cfg.disableNameTags,
                () -> { cfg.disableNameTags  = !cfg.disableNameTags;  ConfigManager.save(); clearAndInit(); }); y += rowH;

        chunkLabelY = y;
        y += sectionH;

        addToggle(col1X, y, colW, btnH, "Optim Chunk Load",cfg.optimizeChunkLoading,
                () -> { cfg.optimizeChunkLoading = !cfg.optimizeChunkLoading; ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col1X, y, colW, btnH, "Fast Chunk Update",cfg.fastChunkUpdates,
                () -> { cfg.fastChunkUpdates = !cfg.fastChunkUpdates; ConfigManager.save(); clearAndInit(); });

        // ==== KOLOM KANAN — VISUAL ====
        visualLabelY = headerH;
        y = visualLabelY + sectionH;

        addToggle(col2X, y, colW, btnH, "Matikan Fog",    cfg.disableFog,
                () -> { cfg.disableFog          = !cfg.disableFog;          ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col2X, y, colW, btnH, "Matikan Awan",   cfg.disableClouds,
                () -> { cfg.disableClouds       = !cfg.disableClouds;       ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col2X, y, colW, btnH, "Matikan Sky",    cfg.disableSkyRendering,
                () -> { cfg.disableSkyRendering = !cfg.disableSkyRendering; ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col2X, y, colW, btnH, "Smooth Lighting",cfg.smoothLighting,
                () -> { cfg.smoothLighting      = !cfg.smoothLighting;      ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col2X, y, colW, btnH, "Biome Fade Red.",cfg.reducedBiomeFade,
                () -> { cfg.reducedBiomeFade    = !cfg.reducedBiomeFade;    ConfigManager.save(); clearAndInit(); }); y += rowH;
        addToggle(col2X, y, colW, btnH, "FPS Counter HUD",cfg.showFpsCounter,
                () -> { cfg.showFpsCounter      = !cfg.showFpsCounter;      ConfigManager.save(); clearAndInit(); });

        // ==== FOOTER BUTTONS ====
        int footerY    = height - footerH + 8;
        int fbtnW      = (panelW - pad * 2 - colGap) / 2;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("§e⚡ Bersihkan RAM"),
                btn -> { MemoryUtils.forceGarbageCollect(); btn.setMessage(Text.literal("§a✔ Selesai!")); }
        ).dimensions(col1X, footerY, fbtnW, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("§cTutup  [K]"),
                btn -> this.close()
        ).dimensions(col2X, footerY, fbtnW, 20).build());
    }

    private void addToggle(int x, int y, int w, int h, String label, boolean value, Runnable action) {
        String status = value ? "§a§lON" : "§c§lOFF";
        addDrawableChild(ButtonWidget.builder(
                Text.literal(label + " §8[" + status + "§8]"),
                btn -> action.run()
        ).dimensions(x, y, w, h).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int panelH = height - 4;

        // Background
        ctx.fill(0, 0, width, height, BG_COLOR);
        ctx.fill(panelX, 2, panelX + panelW, 2 + panelH, PANEL_COLOR);

        // Garis aksen atas
        ctx.fill(panelX, 2, panelX + panelW, 5, ACCENT);

        // Judul
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§b§l⚡ FPS Boost §8| §7v1.0.3 §8| MC 1.21.11", width / 2, 9, ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§7Klik tombol untuk ON/OFF • Tekan §eK§7 untuk tutup", width / 2, 22, DIM_COLOR);

        // Separator header
        ctx.fill(panelX + 8, 36, panelX + panelW - 8, 38, ACCENT);

        // Label section kolom kiri
        ctx.drawTextWithShadow(textRenderer, "§e§l⚙ PERFORMA & ENTITI", panelX + 10, perfLabelY + 3, CAT_COLOR);
        ctx.drawTextWithShadow(textRenderer, "§e§l⚡ CHUNK",             panelX + 10, chunkLabelY + 3, CAT_COLOR);

        // Label section kolom kanan
        int col2LabelX = panelX + (panelW / 2) + 4;
        ctx.drawTextWithShadow(textRenderer, "§e§l🎨 VISUAL",           col2LabelX, visualLabelY + 3, CAT_COLOR);

        // Separator footer
        ctx.fill(panelX + 8, height - 52, panelX + panelW - 8, height - 50, ACCENT);

        // Info RAM
        long maxMem  = Runtime.getRuntime().maxMemory()  / 1024 / 1024;
        long freeMem = Runtime.getRuntime().freeMemory() / 1024 / 1024;
        long usedMem = maxMem - freeMem;
        int pct      = (int) (usedMem * 100 / Math.max(1, maxMem));
        String ramColor = pct > 80 ? "§c" : pct > 60 ? "§e" : "§a";
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§7RAM: " + ramColor + usedMem + " MB §7/ " + maxMem + " MB §8(" + ramColor + pct + "%§8)",
                width / 2, height - 47, 0xFFCCCCCC);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
