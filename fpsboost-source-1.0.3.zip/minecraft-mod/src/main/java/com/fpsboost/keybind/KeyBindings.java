package com.fpsboost.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static KeyBinding OPEN_GUI;

    public static void register() {
        OPEN_GUI = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsboost.open_gui",
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.MISC
        ));
    }
}
