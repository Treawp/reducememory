package com.fpsboost.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.render.fog.FogRenderer;

@Mixin(FogRenderer.class)
public class BackgroundRendererMixin {
}
