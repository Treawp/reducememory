package com.fpsboost.mixin;

import com.fpsboost.config.ConfigManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {

    @Inject(method = "shouldRender",
            at = @At("RETURN"),
            cancellable = true)
    private void fpsboost$onShouldRender(T entity, Frustum frustum,
                                          double cameraX, double cameraY, double cameraZ,
                                          CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) return;

        var cfg = ConfigManager.get();
        if (!cfg.entityCulling) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || entity == client.player) return;

        double maxDist = (double) cfg.entityRenderDistance * cfg.entityRenderDistance;
        if (entity.squaredDistanceTo(client.player) > maxDist) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "renderLabelIfPresent",
            at = @At("HEAD"),
            cancellable = true)
    private void fpsboost$onRenderLabel(S state, net.minecraft.client.util.math.MatrixStack matrices,
                                         net.minecraft.client.render.command.OrderedRenderCommandQueue queue,
                                         net.minecraft.client.render.state.CameraRenderState cameraState,
                                         CallbackInfo ci) {
        if (ConfigManager.get().disableNameTags) {
            ci.cancel();
        }
    }
}
