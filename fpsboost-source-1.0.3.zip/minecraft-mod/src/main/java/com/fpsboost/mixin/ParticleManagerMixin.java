package com.fpsboost.mixin;

import com.fpsboost.config.ConfigManager;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"),
            cancellable = true)
    private void fpsboost$onAddParticle(ParticleEffect parameters, double x, double y, double z,
                                         double velocityX, double velocityY, double velocityZ,
                                         CallbackInfoReturnable<Particle> cir) {
        var cfg = ConfigManager.get();

        if (cfg.disableAllParticles) {
            cir.setReturnValue(null);
            return;
        }

        if (cfg.reduceParticles) {
            if (Math.random() < 0.5) {
                cir.setReturnValue(null);
            }
        }
    }
}
