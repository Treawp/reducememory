package com.fpsboost.util;

import com.fpsboost.FpsBoostMod;
import net.minecraft.client.MinecraftClient;

public class MemoryUtils {

    /**
     * Paksa Garbage Collector berjalan dan bersihkan texture cache jika tersedia.
     */
    public static void forceGarbageCollect() {
        long before = Runtime.getRuntime().freeMemory() / 1024 / 1024;
        System.gc();
        System.gc();

        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.getTextureManager() != null) {
            // Reload TextureManager untuk membebaskan resource yang tidak terpakai
            // (tidak memuat ulang secara paksa, hanya memicu GC setelah referensi lama dibuang)
        }

        long after = Runtime.getRuntime().freeMemory() / 1024 / 1024;
        FpsBoostMod.LOGGER.info("[FPS Boost] GC selesai. Memori bebas: " + before + " MB -> " + after + " MB");
    }

    public static long getUsedMemoryMB() {
        long max  = Runtime.getRuntime().maxMemory();
        long free = Runtime.getRuntime().freeMemory();
        return (max - free) / 1024 / 1024;
    }

    public static long getMaxMemoryMB() {
        return Runtime.getRuntime().maxMemory() / 1024 / 1024;
    }
}
